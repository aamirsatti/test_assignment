<?php include('includes/header.php'); ?>
<link rel="stylesheet" type="text/css" href="//cdn.datatables.net/1.10.25/css/jquery.dataTables.min.css">
<script src="//cdn.datatables.net/1.10.25/js/jquery.dataTables.min.js" type="text/javascript"></script>

<div class="content">
    <div class="header"><h1 class="page-title">Events</h1></div>
	<div class="main-content">
		<div class="btn-toolbar list-toolbar">
			<div class="row">
				<form id="search_filters" method="post">
					<div class="col-md-3">
						<div class="form-group">
							<input type="text" id="employee_name" name="employee_name" placeholder="Employee Name" class="form-control">
						</div>
					</div>
					<div class="col-md-3">
						<div class="form-group">
							<input type="text" id="event_name" name="event_name" placeholder="Event Name" class="form-control">
						</div>
					</div>
					<div class="col-md-3">
						<div class="form-group">
							<input type="date" id="date" name="date" placeholder="Date" class="form-control">
						</div>
					</div>
					<div class="col-md-3">
						<button type="submit" class="btn btn-primary"> Search</button>
					</div>
					
				</form>
			</div>
		</div>
		<table class="table" id="event_table">
			<thead>
				<tr>
					<th>#</th>
					<th>Employee Name</th>
					<th>Employee Email</th>
					<th>Eevent Id</th>
					<th>Eevent Name</th>
					<th>Participation Fee</th>
					<th>Eevent Date</th>
					<th>Version</th>
				</tr>
			</thead>
			<tbody id="event_data">
				<?php 
				
				?>
			</tbody>
			<tfoot>
            <tr>
                <th colspan="5" style="text-align:right">Total:</th>
                <th colspan="3"></th>
            </tr>
        </tfoot>
		</table>
        <div id="message_area" style="display:none;"></div>

		

<?php include('includes/footer.php'); ?>
<script>
$(document).ready( function () {
    
} );
</script>