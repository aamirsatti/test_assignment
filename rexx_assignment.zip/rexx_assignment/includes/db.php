<?php 
!defined('INDEX') OR exit('No direct script access allowed');
class database
{
	private $server;
	private $username;
	private $password;
	private $db_name;
	private $conn;
	
	public function __construct()
	{
		$this->username = "root";
        $this->server = "localhost";
        $this->password = "";
        $this->db_name = "test_assignment";
		$this->conn = $this->connect();
		if ($this->conn->connect_error) {
		   die("Connection failed: " . $this->conn->connect_error);
		}
	}
	
	public function connect()
    {
        $link = new mysqli($this->server, $this->username, $this->password, $this->db_name);
        return $link;
    }
	// Clean data
	private function clean_data($data)
	{
		return $this->conn->real_escape_string($data);
	}
	// Insert
	public function insert_event_data($data)
	{
		$sql = "INSERT INTO event_booking 
				SET
				 participation_id = ".$this->clean_data($data->participation_id).",
				 employee_name = '".$this->clean_data($data->employee_name)."',
				 employee_mail = '".$this->clean_data($data->employee_mail)."',
				 event_id = ".$this->clean_data($data->event_id).",
				 event_name = '".$this->clean_data($data->event_name)."',
				 participation_fee = '".$this->clean_data($data->participation_fee)."',
				 event_date = '".$this->clean_data($data->event_date)."',
				 version = '".$this->clean_data($data->version)."'
				";

		if ($this->conn->query($sql) === TRUE) 
			return true;
		else 
		   return false;
		
	}
	// Get data
	public function get_event_data($search_filters)
	{
		$employee_name = isset($search_filters['employee_name']) ? $search_filters['employee_name'] : '';
		$event_name = isset($search_filters['event_name']) ? $search_filters['event_name'] : '';
		$date = isset($search_filters['date']) ? $search_filters['date'] : '';
		$where = ' WHERE id > 0 ';
		if(isset($search_filters['employee_name']) && $search_filters['employee_name'] != '')
		{
			if($where != '')
				$where .= ' AND ';
			$where .= 'employee_name LIKE "%'.$this->clean_data($search_filters['employee_name']).'%" ';
		}
		if(isset($search_filters['event_name']) && $search_filters['event_name'] != '')
		{
			if($where != '')
				$where .= ' AND ';
			$where .= ' event_name LIKE "%'.$this->clean_data($search_filters['event_name']).'%" ';
		}
		if(isset($search_filters['date']) && $search_filters['date'] != '')
		{
			if($where != '')
				$where .= ' AND ';
			$where .= ' DATE(event_date) = "'.$this->clean_data($search_filters['date']).'" ';
		}
		$sql = "Select * from event_booking ".$where." "; 
		$result = $this->conn->query($sql);
		return $result;	
	}
}
?>