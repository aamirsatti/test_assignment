<?php
!defined('INDEX') OR exit('No direct script access allowed');

include 'model.php';
$model = new Model();
if(!empty($_FILES['json_file']) && $_FILES['json_file']['name'] != '')
{
	// Check file is JSON or not
	$allowed = array('json', 'JSON');
	$filename = $_FILES['json_file']['name'];
	$ext = pathinfo($filename, PATHINFO_EXTENSION);
	if (!in_array($ext, $allowed)) 
	{
		echo json_encode(array('status' => 'error',
							   'msg' => 'Invalid File Format'));
	}
	else
	{
		// read file
		if($_FILES['json_file']['tmp_name'] != '')
		{
			$readFile = $model->readtempfile($_FILES['json_file']['tmp_name']);
			if($readFile)
				echo json_encode(array('status' => 'success',
								       'msg' => 'Data insert successfully.'));
			else
				echo json_encode(array('status' => 'error',
								       'msg' => 'Something wrong, either file is empty OR invalid'));
		}
		else
			echo json_encode(array('status' => 'error',
								   'msg' => 'File not found'));
	}
}
else
	echo json_encode(array('status' => 'error',
						   'msg' => 'Please Add File'));
exit;

?>