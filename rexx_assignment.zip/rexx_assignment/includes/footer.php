	<footer>
		<hr>

			<!-- Purchase a site license to remove this link from the footer: http://www.portnine.com/bootstrap-themes -->
		<script src="assets/lib/custom.js?v=<?php echo rand();?>" type="text/javascript"></script>
	 </footer>
	</div>
</div>

  
</body></html>