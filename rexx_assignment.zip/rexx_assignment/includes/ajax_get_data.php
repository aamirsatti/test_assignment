<?php
!defined('INDEX') OR exit('No direct script access allowed');

include 'model.php';
$model = new Model();
// Search Filters
$search_filters = $_POST;
$event_data = $model->get_event_data($search_filters);

if(!empty($event_data) )
	echo json_encode(array('status' => 'success',
						   'data' => $event_data));	
else
	echo json_encode(array('status' => 'error',
							'msg' => 'Something wrong'));
exit;

?>