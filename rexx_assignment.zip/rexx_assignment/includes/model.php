<?php
!defined('INDEX') OR exit('No direct script access allowed');
include 'db.php';
class model
{
	private $db;
	
	public function __construct()
	{
		$this->db = new Database();
		
	}

	// Read File
	public function readtempfile($temp_file)
	{
		$fileContent = file_get_contents($temp_file); 
		$data_in_array = json_decode($fileContent);
		if(!empty($data_in_array))
		{
			foreach($data_in_array as $data)
				$insertData = $this->db->insert_event_data($data);
			return true;
		}
		else
			return false;
		
	}

    // get data from db 
    public function get_event_data($search_filters)
	{
		$getData = $this->db->get_event_data($search_filters);
		$data = '';
		$total_fee = 0;
		if(mysqli_num_rows($getData) > 0)
		{
			$counter = 1;
			while($rec = $getData->fetch_object())
			{
				// Check Timezone
				$version = 	explode("+",$rec->version);
				if(isset($version[0]) && $version[0] <= '1.0.17')  
				{
					if(isset($version[1]) && $version[1] <= 60)
						$timezone = 'Europe/Berlin';
					else if ($version[1] > 60 && $version[0] == '1.0.17')
						$timezone = 'UTC';
					else
						$timezone = 'Europe/Berlin';
				}
				else
					$timezone = 'UTC';
				$data .= '<tr>
							<td>'.$counter.'</td>
							<td>'.$rec->employee_name.'</td>
							<td>'.$rec->employee_mail.'</td>
							<td>'.$rec->event_id.'</td>
							<td>'.$rec->event_name.'</td>
							<td>€'.$rec->participation_fee.'</td>
							<td>'.date('d/m/Y g:i A', strtotime($rec->event_date)).' ('.$timezone.')</td>
							<td>'.$rec->version.'</td>
						  </tr>';
				$counter++;	
				$total_fee = $total_fee + $rec->participation_fee;	
					
			}
		}
		
		
		return $data;  //array('data' => $data,
					 //'total_fee' => );
	}		
}

?>