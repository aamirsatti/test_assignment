<?php include('includes/header.php'); ?>
<div class="content">
        <div class="header">
            
            <h1 class="page-title">New File</h1>
        </div>
	<div class="main-content">
		<div class="row">
			<div class="col-md-6">
				<br>
				<form id="file_upload" method="post" enctype="multipart/form-data">
					<div class="form-group">
						<label>JSON File</label>
						<input type="file" value="" id="json_file" name="json_file" class="form-control">
					</div>
					<div class="btn-toolbar list-toolbar">
						<button type="submit" class="btn btn-primary"><i class="fa fa-save"></i> Upload</button>
					</div>
				</form>
				<div id="message_area" style="display:none;"></div>
			</div>
		</div>

<?php include('includes/footer.php'); ?>
