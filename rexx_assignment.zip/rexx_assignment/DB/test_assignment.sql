/*
SQLyog Enterprise - MySQL GUI v7.02 
MySQL - 5.5.5-10.1.33-MariaDB : Database - test_assignment
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

/*Table structure for table `event_booking` */

DROP TABLE IF EXISTS `event_booking`;

CREATE TABLE `event_booking` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `participation_id` int(11) DEFAULT NULL,
  `employee_name` varchar(150) DEFAULT NULL,
  `employee_mail` varchar(200) DEFAULT NULL,
  `event_id` int(11) DEFAULT NULL,
  `event_name` varchar(255) DEFAULT NULL,
  `participation_fee` decimal(10,2) DEFAULT NULL,
  `event_date` datetime DEFAULT NULL,
  `version` varchar(100) DEFAULT NULL,
  `createdDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

/*Data for the table `event_booking` */

insert  into `event_booking`(`id`,`participation_id`,`employee_name`,`employee_mail`,`event_id`,`event_name`,`participation_fee`,`event_date`,`version`,`createdDate`) values (1,1,'Reto Fanzen','reto.fanzen@no-reply.rexx-systems.com',1,'PHP 7 crash course','0.00','2019-09-04 08:00:00','1.0.17+42','2022-03-03 19:18:58'),(2,2,'Reto Fanzen','reto.fanzen@no-reply.rexx-systems.com',2,'International PHP Conference','1485.99','2019-10-21 10:00:00','1.0.17+59','2022-03-03 19:18:58'),(3,3,'Leandro BuÃŸmann','leandro.bussmann@no-reply.rexx-systems.com',2,'International PHP Conference','657.50','2019-10-21 10:00:00','1.0.15+83','2022-03-03 19:18:58'),(4,4,'Hans SchÃ¤fer','hans.schaefer@no-reply.rexx-systems.com',1,'PHP 7 crash course','0.00','2019-09-04 06:00:00','1.0.17+65','2022-03-03 19:18:58'),(5,5,'Mia Wyss','mia.wyss@no-reply.rexx-systems.com',1,'PHP 7 crash course','0.00','2019-09-04 06:00:00','1.0.17+65','2022-03-03 19:18:58'),(6,6,'Mia Wyss','mia.wyss@no-reply.rexx-systems.com',2,'International PHP Conference','657.50','2019-10-21 08:00:00','1.1.3','2022-03-03 19:18:58'),(7,7,'Reto Fanzen','reto.fanzen@no-reply.rexx-systems.com',3,'code.talks','474.81','2019-10-24 08:00:00','1.0.17+59','2022-03-03 19:18:58'),(8,8,'Hans SchÃ¤fer','hans.schaefer@no-reply.rexx-systems.com',3,'code.talks','534.31','2019-10-24 06:00:00','1.1.3','2022-03-03 19:18:58');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
